claudia = input("Did Claudia accept the invitation? (Y/N) ")
amor = input("Did Amor accept the invitation? (Y/N) ")

if claudia == "Y" and amor == "Y":
    print("Chaos will ensue.")
else:
    print("There will be no chaos.")

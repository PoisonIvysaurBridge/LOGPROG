one = float(input("What's the first person's height in meters? "))
two = float(input("What's the second person's height in meters? "))
three = float(input("What's the third person's height in meters? "))

one = one * 3.28084
two = two * 3.28084
three = three * 3.28084

if one <= two and two <= three:
    print(one, "feet", two, "feet", three, "feet")
elif one <= three and three <= two:
    print(one, "feet", three, "feet", two, "feet")
    
elif two <= one and one <= three:
    print(two, "feet", one, "feet", three, "feet")
elif two <= three and three <= one:
    print(two, "feet", three, "feet", one, "feet")

elif three <= two and two <= one:
    print(three, "feet", two, "feet", one, "feet")
elif one <= two and three <= one:
    print(three, "feet", one, "feet", two, "feet")

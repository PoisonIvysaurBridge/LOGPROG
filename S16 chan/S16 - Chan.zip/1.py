grade = int(input("What's your grade? "))

if grade >= 90:
    print("Very good!")

age = int(input("How old are you? "))

if age >= 18:
    if age <= 35:
        print("You can join!")
    else:
        print("You can't join.")
else:
    print("You can't join.")
